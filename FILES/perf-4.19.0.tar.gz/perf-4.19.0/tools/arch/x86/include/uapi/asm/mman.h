/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#ifndef TOOLS_ARCH_X86_UAPI_ASM_MMAN_FIX_H
#define TOOLS_ARCH_X86_UAPI_ASM_MMAN_FIX_H
#define MAP_32BIT	0x40
#include <uapi/asm-generic/mman.h>
#endif
