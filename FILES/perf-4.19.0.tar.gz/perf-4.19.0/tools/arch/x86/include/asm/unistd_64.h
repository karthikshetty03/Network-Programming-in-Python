/* SPDX-License-Identifier: GPL-2.0 */
#ifndef __NR_perf_event_open
# define __NR_perf_event_open 298
#endif
#ifndef __NR_futex
# define __NR_futex 202
#endif
#ifndef __NR_gettid
# define __NR_gettid 186
#endif
#ifndef __NR_getcpu
# define __NR_getcpu 309
#endif
#ifndef __NR_setns
#define __NR_setns 308
#endif
