// SPDX-License-Identifier: LGPL-2.1
#ifndef BPF_STR_ERROR
#define BPF_STR_ERROR

char *str_error(int err, char *dst, int len);
#endif // BPF_STR_ERROR
